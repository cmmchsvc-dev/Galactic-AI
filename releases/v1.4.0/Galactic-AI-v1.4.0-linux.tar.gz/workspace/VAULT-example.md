## Personal Info

- **Email:** your.email@example.com

## Credentials

- **GitHub Token:** ghp_xxxxxxxxxxxxxxxxxxxx

*(Rename this file to VAULT.md to use it)*
